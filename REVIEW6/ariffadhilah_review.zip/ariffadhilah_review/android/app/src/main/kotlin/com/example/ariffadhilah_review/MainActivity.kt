package com.example.ariffadhilah_review

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
