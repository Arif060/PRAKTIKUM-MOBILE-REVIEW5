import 'package:ariffadhilah_review/controller/main_controller.dart';
import 'package:ariffadhilah_review/model/task.dart';
import 'package:flutter/material.dart';

class MainController with ChangeNotifier {
  final TaskData _taskData = TaskData();

  // Mengambil daftar semua tugas
  List<Task> get tasks => _taskData.tasks;

  // Mengambil jumlah tugas
  int get taskCount => _taskData.taskCount;

  // Menambah tugas baru
  void addNewTask(String taskName) {
    _taskData.addTask(taskName);
    notifyListeners(); // Pemberitahuan bahwa ada perubahan dalam data
  }

  // Memperbarui status tugas (selesai atau belum)
  void updateTaskStatus(Task task) {
    _taskData.updateTask(task);
    notifyListeners();
  }

  // Menghapus tugas dari daftar
  void removeTask(Task task) {
    _taskData.deleteTask(task);
    notifyListeners();
  }
}
