import 'task.dart';

class TaskData {
  List<Task> tasks = [];

  int get taskCount => tasks.length;

  void addTask(String taskName) {
    final task = Task(name: taskName);
    tasks.add(task);
  }

  void updateTask(Task task) {
    task.isDone = !task.isDone;
  }

  void deleteTask(Task task) {
    tasks.remove(task);
  }
}
