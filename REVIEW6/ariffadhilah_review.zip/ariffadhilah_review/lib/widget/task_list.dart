import 'package:ariffadhilah_review/widget/task_file.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:ariffadhilah_review/controller/main_controller.dart'; // Pastikan jalur ini benar
// ignore: unused_import
import 'package:ariffadhilah_review/widget/task_tile.dart';

class TaskList extends StatelessWidget {
  const TaskList({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<TaskData>(
      builder: (context, taskData, child) {
        return ListView.builder(
          itemCount: taskData.taskCount,
          itemBuilder: (context, index) {
            final task = taskData.tasks[index];
            return TaskTile(
              taskTitle: task.name,
              isChecked: task.isDone,
              checkboxCallback: (checkboxState) {
                taskData.updateTask(task);
              },
              longPressCallback: () {
                taskData.deleteTask(task);
              },
            );
          },
        );
      },
    );
  }
}
