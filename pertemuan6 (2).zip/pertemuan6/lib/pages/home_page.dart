import 'package:flutter/material.dart';
import 'dart:math'; // Untuk mengubah warna secara acak

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color.fromARGB(255, 204, 94, 10),
        ),
        useMaterial3: true,
      ),
      home: ThemeScreen(),
    );
  }
}

class ThemeScreen extends StatefulWidget {
  @override
  _ThemeScreenState createState() => _ThemeScreenState();
}

class _ThemeScreenState extends State<ThemeScreen> {
  // Warna default untuk background
  Color backgroundColor = Colors.white;

  // Fungsi untuk menghasilkan warna acak
  void changeBackgroundColor() {
    setState(() {
      backgroundColor = Color.fromARGB(
        255,
        Random().nextInt(256), // Nilai R (Red)
        Random().nextInt(256), // Nilai G (Green)
        Random().nextInt(256), // Nilai B (Blue)
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ganti Background RGB'),
        backgroundColor: const Color.fromARGB(255, 204, 94, 10),
      ),
      body: GestureDetector(
        onTap: changeBackgroundColor, // Mengubah warna saat layar ditekan
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 500),
          color: backgroundColor, // Warna latar belakang yang bisa berubah
          child: Center(
            child: const Text(
              'Tekan untuk mengubah warna background!',
              style: TextStyle(fontSize: 20, color: Colors.black),
            ),
          ),
        ),
      ),
    );
  }
}
