import 'package:flutter/material.dart';
import 'dart:math'; // Untuk menghasilkan warna acak
import 'dart:async'; // Untuk Timer

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'WARUNG PECEL PAK NARYO',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color.fromARGB(255, 221, 255, 0),
        ),
        useMaterial3: true,
      ),
      home: IntroductionScreen(),
    );
  }
}

// Introduction Screen dengan gambar sebagai background
class IntroductionScreen extends StatefulWidget {
  @override
  _IntroductionScreenState createState() => _IntroductionScreenState();
}

class _IntroductionScreenState extends State<IntroductionScreen> {
  @override
  void initState() {
    super.initState();
    // Timer untuk berpindah ke layar utama setelah 3 detik
    Timer(const Duration(seconds: 3), () {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => ThemeScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(
                'd:\WhatsApp Image 2024-10-16 at 10.48.14.jpeg'), // Ganti dengan path gambar Anda
            fit: BoxFit.cover, // Menutupi seluruh layar
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              Text(
                'Selamat Datang di Warung Pecel Pak Naryo',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 20),
              CircularProgressIndicator(
                color: Colors.white,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ThemeScreen extends StatefulWidget {
  @override
  _ThemeScreenState createState() => _ThemeScreenState();
}

class _ThemeScreenState extends State<ThemeScreen> {
  // Warna background default
  Color backgroundColor = Colors.white;

  // Fungsi untuk mengganti warna background secara acak
  void changeBackgroundColor() {
    setState(() {
      backgroundColor = Color.fromARGB(
        255,
        Random().nextInt(256), // R (Red)
        Random().nextInt(256), // G (Green)
        Random().nextInt(256), // B (Blue)
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SUNARYO'),
      ),
      body: Container(
        color:
            backgroundColor, // Menggunakan warna background yang dapat berubah
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text('ini Headline Large',
                  style: Theme.of(context).textTheme.headlineLarge),
              const SizedBox(height: 20),
              Text('ini Body Large',
                  style: Theme.of(context).textTheme.bodyLarge),
              Text('ini Body Medium',
                  style: Theme.of(context).textTheme.bodyMedium),
              Text('ini Body Small',
                  style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed:
                    changeBackgroundColor, // Memanggil fungsi saat tombol ditekan
                child: const Text('ini Ganti Background'),
              ),
              const SizedBox(height: 20),
              OutlinedButton(
                onPressed: () {},
                child: const Text('ini Outlined Button'),
              ),
              const SizedBox(height: 20),
              TextButton(
                onPressed: () {},
                child: const Text('ini Text Button'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
